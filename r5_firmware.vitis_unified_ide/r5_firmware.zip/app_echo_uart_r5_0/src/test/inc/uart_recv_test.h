/*
    uart_recv_test.h
    author: sh-goto
*/

#ifndef UART_RECV_TEST_H
#define UART_RECV_TEST_H

void InitUartRecvTest(void);

#endif /* UART_RECV_TEST_H */

