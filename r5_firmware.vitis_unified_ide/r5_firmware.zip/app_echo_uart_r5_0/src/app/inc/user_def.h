/*
    user_def.h
    author: sh-goto
*/

#ifndef USER_DEF_H
#define USER_DEF_H

typedef enum {
    eSUCCESS = 0,
    eFAILURE = -1
} eErr_t;

#endif /* USER_DEF_H */

