/*
    uart_loopback_test.h
    author: sh-goto
*/

#ifndef UART_LOOPBACK_TEST_H
#define UART_LOOPBACK_TEST_H

void InitUartLoopbackTest(void);

#endif /* UART_LOOPBACK_TEST_H */

