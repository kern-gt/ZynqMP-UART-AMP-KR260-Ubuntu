/*
    hardware_def.h
    author: sh-goto
*/

#ifndef REG_DUMP_H
#define REG_DUMP_H

void ReadRegisterPLxRefCtrl(void);

#endif /* REG_DUMP_H */

